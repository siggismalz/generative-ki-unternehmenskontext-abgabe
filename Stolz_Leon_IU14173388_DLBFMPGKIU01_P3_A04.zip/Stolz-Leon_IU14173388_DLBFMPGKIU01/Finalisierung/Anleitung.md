# Den Demonstrator und die Ergebnisse nachvollziehen

Öffnen Sie die drei PDFs in diesem Ordner. A01 fasst Konzept, Entwicklung und Ergebnis zusammen. A02 enthält die untersuchten Texte sowie die Diskussion beider Promptvarianten. Mit A03 können Sie zwei dieser Übersetzungen am Demonstrator selbst erproben. Der Anforderungsabgleich dokumentiert den Stand der 22 Kriterien aus dem Konzept.

## Lokal starten

Unter Windows x64 im Unterordner `Anwendung` zuerst `Einrichten.cmd` ausführen. Der erste Lauf lädt rund 2,53 GB und prüft die SHA-256-Werte von Python, llama.cpp und Qwen3-4B. Etwa 6 GB freien Speicher vorsehen. Anschließend `Starten.cmd` öffnen. Der Browser erreicht die lokale Oberfläche unter http://127.0.0.1:8767. Zum Beenden die Schaltfläche in der Oberfläche nutzen. Eine detaillierte Bedienungsanleitung und die Original-Lizenzen liegen in `Anwendung`. Der getestete Code ist auch im Unterordner `Erarbeitung_final/Anwendung` des Gesamtarchivs enthalten.

## Versuche wiederholen

Für die folgenden Befehle im Windows-Explorer diesen Ordner `Finalisierung` öffnen, in die Adressleiste `cmd` eingeben und mit der Eingabetaste bestätigen. Die Anwendung muss zuvor eingerichtet sein. Für jeden Versuch einen neuen Ergebnisnamen verwenden.

```bat
Anwendung\laufzeit\python\python.exe -B -X utf8 Fallstudie\laeufe.py Anwendung Wiederholung
Anwendung\laufzeit\python\python.exe -B -X utf8 Nachweise\technik_pruefen.py Anwendung Wiederholung_Technik.json
```

Das erste Skript verarbeitet beide Prompts in derselben festgelegten Fallreihenfolge. `Fallstudie/Faelle_vorab.json` enthält Eingaben, Arbeitsreferenzen und Sollinhalt. Die 48 Ausgaben des ausgewerteten Laufs stehen in `Fallstudie/Rohdaten.json`, die Zuordnung zum Modell- und Programmstand in `Fallstudie/Provenienz.json`. Die fallweisen Beurteilungen in `Fallstudie/Vorbewertung.json` sind KI-gestützt. Das zweite Skript führt die technischen Prüfungen und die Kontrollen veränderter Beträge, Mengen und Kennungen aus.

In `Nachweise/isolierter_aufbau.json` ist der Test der Ersteinrichtung aus lokalen, hashgeprüften Originaldateien dokumentiert. Die P1- und P2-PDFs mit Konzept, Literatur, Aufbau und Entwicklungsnachweisen stehen in `Dokumentation`. Der Unterordner `Sprachpruefung` enthält den Bogen zur eigenständigen fachlichen Bewertung der unveränderten Ausgaben von Handel v2. Ein später ergänztes persönliches Protokoll trägt den Namen `Sprachpruefung.pdf`.

