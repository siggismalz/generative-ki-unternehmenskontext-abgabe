# Deutsch und Englisch im Kundenservice

Was passiert, wenn ein Übersetzer aus einer Glasschüssel einen Glasbecher macht? An solchen Beispielen untersucht das Projekt, welche Entwürfe ein kleiner Onlinehändler übernehmen kann und welche er korrigieren muss.

**Zum Lesen:** Die [Beispielsammlung](Finalisierung/Stolz_Leon_IU14173388_DLBFMPGKIU01_P3_A02.pdf) enthält die Ergebnisse. Fall N02 zeigt eine gelungene Serviceantwort, N11 eine falsche Artikelbezeichnung.

**Zum Ausprobieren:** Unter Windows x64 im Ordner [Finalisierung/Anwendung](Finalisierung/Anwendung) beim ersten Mal `Einrichten.cmd` öffnen (rund 2,53 GB Download), dann `Starten.cmd`. Die [Vorführanleitung](Finalisierung/Stolz_Leon_IU14173388_DLBFMPGKIU01_P3_A03.pdf) enthält zwei Texte zum Einfügen.

In [Konzeption](Konzeption) stehen die Anforderungen, in [Erarbeitung](Erarbeitung) die erste Umsetzung. [Finalisierung](Finalisierung) enthält den getesteten Übersetzer, die Fallstudie und die [Originalausgaben](Finalisierung/Fallstudie/Rohdaten.json). Die Ordner `Konzeption_final` und `Erarbeitung_final` sind die erneut eingereichten Fassungen der beiden ersten Meilensteine.

Im [zweiten Bewertungsdurchgang durch OpenAI Codex](Finalisierung/Sprachpruefung/Sprachbewertung_Codex.pdf) bestehen 10 von 16 Normalfällen. Anders als in der Vorbewertung der Fallstudie (9 von 16) erhält N10 hier 7 Punkte. Die persönliche Sprachabnahme steht noch aus.
