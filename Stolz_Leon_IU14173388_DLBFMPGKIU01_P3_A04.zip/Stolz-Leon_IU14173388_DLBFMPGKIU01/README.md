# Deutsch und Englisch im Kundenservice

Was passiert, wenn ein Übersetzer aus einer Glasschüssel einen Glasbecher macht? An solchen Beispielen untersucht das Projekt, welche Entwürfe ein kleiner Onlinehändler übernehmen kann und welche er korrigieren muss.

Die [Beispielsammlung](Finalisierung/Stolz_Leon_IU14173388_DLBFMPGKIU01_P3_A02.pdf) zeigt in Fall N02 eine gelungene Serviceantwort und in N11 eine falsche Artikelbezeichnung. In der [persönlichen Sprachprüfung](Finalisierung/Sprachpruefung/Sprachpruefung.pdf) bestanden zehn von 16 Normalfällen mit Handel v2.

**Zum Ausprobieren:** Unter Windows x64 im Ordner [Finalisierung/Anwendung](Finalisierung/Anwendung) beim ersten Mal `Einrichten.cmd` öffnen (rund 2,53 GB Download), dann `Starten.cmd`. Die [Vorführanleitung](Finalisierung/Stolz_Leon_IU14173388_DLBFMPGKIU01_P3_A03.pdf) enthält zwei Texte zum Einfügen.

In [Konzeption](Konzeption) stehen die Anforderungen, in [Erarbeitung](Erarbeitung) die erste Umsetzung. [Finalisierung](Finalisierung) enthält den getesteten Übersetzer, die Fallstudie und die [Originalausgaben](Finalisierung/Fallstudie/Rohdaten.json). Die Ordner `Konzeption_final` und `Erarbeitung_final` sind die erneut eingereichten Fassungen der beiden ersten Meilensteine.
